public class K extends null {

    int af();

    Object gg();

    public java.util.Random mm() {
        return new java.util.Random();
    }
}
