public class J extends null {

    String kk();

    long dd();

    public int ae() {
        return 8;
    }
}
