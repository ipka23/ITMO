public interface D {

    float ff();

    double ad();
}
