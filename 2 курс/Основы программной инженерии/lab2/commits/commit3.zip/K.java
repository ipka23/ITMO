public interface K {

    int af();

    Object gg();
}
