public interface B {

    java.util.Random mm();

    int hh();
}
