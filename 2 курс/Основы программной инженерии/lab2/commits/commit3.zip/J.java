public interface J {

    String kk();

    long dd();
}
