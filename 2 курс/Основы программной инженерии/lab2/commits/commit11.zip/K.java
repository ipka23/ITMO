public class K extends null {

    int af();

    Object gg();
}
