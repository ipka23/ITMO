public class B extends null {

    java.util.Random mm();

    int hh();
}
