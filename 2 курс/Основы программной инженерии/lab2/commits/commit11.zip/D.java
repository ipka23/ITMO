public class D extends null {

    float ff();

    double ad();
}
