public class J extends null {

    String kk();

    long dd();
}
